import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog
from tkinter import messagebox
import json
import os

class MyFitApp:
    def __init__(self, master):
        self.master = master
        self.master.title("MyFitApp")

        self.logged_in = False
        self.current_user = None
        self.users = {}  # Armazenará informações sobre os usuários

        self.load_data()

        self.create_login_ui()

    def create_login_ui(self):
        self.login_frame = tk.Frame(self.master)
        self.login_frame.pack(padx=20, pady=20)

        self.email_label = tk.Label(self.login_frame, text="Email:")
        self.email_label.grid(row=0, column=0, sticky=tk.E)

        self.email_entry = tk.Entry(self.login_frame)
        self.email_entry.grid(row=0, column=1)

        self.password_label = tk.Label(self.login_frame, text="Senha:")
        self.password_label.grid(row=1, column=0, sticky=tk.E)

        self.password_entry = tk.Entry(self.login_frame, show="*")
        self.password_entry.grid(row=1, column=1)

        self.login_button = tk.Button(self.login_frame, text="Login", command=self.login)
        self.login_button.grid(row=2, column=0, columnspan=2, pady=10)

        self.create_account_button = tk.Button(self.login_frame, text="Criar Conta", command=self.create_account)
        self.create_account_button.grid(row=3, column=0, columnspan=2)

    def login(self):
        email = self.email_entry.get()
        password = self.password_entry.get()

        # Verifica se o email e senha correspondem a um usuário existente
        if email in self.users and self.users[email]["password"] == password:
            self.logged_in = True
            self.current_user = email
            self.show_main_menu()
        else:
            messagebox.showerror("Erro de Login", "Email ou senha incorretos.")

    def create_account(self):
        email = simpledialog.askstring("Criar Conta", "Digite seu email:")
        password = simpledialog.askstring("Criar Conta", "Digite sua senha:")

        if email and password:
            # Adiciona o novo usuário à lista de usuários
            self.users[email] = {"password": password}
            messagebox.showinfo("Conta Criada", "Sua conta foi criada com sucesso.")
        else:
            messagebox.showerror("Erro", "Email e senha são obrigatórios.")

    def show_main_menu(self):
        self.login_frame.destroy()

        self.main_menu_frame = tk.Frame(self.master)
        self.main_menu_frame.pack(padx=20, pady=20)

        welcome_label = tk.Label(self.main_menu_frame, text=f"Bem vindo ao seu MyFitApp, {self.current_user}!")
        welcome_label.pack(pady=10)

        add_workout_button = tk.Button(self.main_menu_frame, text="Adicionar Treino", command=self.add_workout)
        add_workout_button.pack()

        view_workout_button = tk.Button(self.main_menu_frame, text="Visualizar Treino", command=self.view_workout)
        view_workout_button.pack()

        edit_workout_button = tk.Button(self.main_menu_frame, text="Editar Treino", command=self.edit_workout)
        edit_workout_button.pack()

    def add_workout(self):
        if not self.logged_in:
            messagebox.showerror("Erro", "Você precisa fazer login primeiro.")
            return

        workout_name = simpledialog.askstring("Adicionar Treino", "Digite o nome do treino:")
        if workout_name:
            self.workouts[workout_name] = {"exercises": []}
            self.add_exercise_to_workout(workout_name)

    def add_exercise_to_workout(self, workout_name):
        exercise_name = simpledialog.askstring("Adicionar Exercício", "Digite o nome do exercício:")
        if exercise_name:
            series = simpledialog.askinteger("Adicionar Exercício", "Número de séries:")
            repetitions = simpledialog.askinteger("Adicionar Exercício", "Número de repetições:")
            load = simpledialog.askfloat("Adicionar Exercício", "Carga utilizada:")

            exercise = {"name": exercise_name, "series": series, "repetitions": repetitions, "load": load}
            self.workouts[workout_name]["exercises"].append(exercise)

            add_more = messagebox.askyesno("Adicionar Exercício", "Deseja adicionar mais um exercício?")
            if add_more:
                self.add_exercise_to_workout(workout_name)
            else:
                messagebox.showinfo("Treino Concluído", "Treino adicionado com sucesso.")
            self.save_data()  # Salva os dados após adicionar um exercício

    def view_workout(self):
        if not self.logged_in:
            messagebox.showerror("Erro", "Você precisa fazer login primeiro.")
            return

        if not self.workouts:
            messagebox.showinfo("Nenhum Treino", "Você ainda não adicionou nenhum treino.")
            return

        workout_name = simpledialog.askstring("Visualizar Treino", "Digite o nome do treino:")
        if workout_name and workout_name in self.workouts:
            exercises = self.workouts[workout_name]["exercises"]
            self.show_workout_table(workout_name, exercises)
        else:
            messagebox.showerror("Erro", "Treino não encontrado.")

    def show_workout_table(self, workout_name, exercises):
        workout_table_window = tk.Toplevel(self.master)
        workout_table_window.title(f"{workout_name} - Exercícios")

        tree = ttk.Treeview(workout_table_window, columns=("name", "series", "repetitions", "load"), show="headings")
        tree.heading("name", text="Exercício")
        tree.heading("series", text="Séries")
        tree.heading("repetitions", text="Repetições")
        tree.heading("load", text="Carga")

        for exercise in exercises:
            tree.insert("", "end", values=(exercise["name"], exercise["series"], exercise["repetitions"], exercise["load"]))

        tree.pack()

    def edit_workout(self):
        if not self.logged_in:
            messagebox.showerror("Erro", "Você precisa fazer login primeiro.")
            return

        if not self.workouts:
            messagebox.showinfo("Nenhum Treino", "Você ainda não adicionou nenhum treino.")
            return

        workout_name = simpledialog.askstring("Editar Treino", "Digite o nome do treino:")
        if workout_name and workout_name in self.workouts:
            exercises = self.workouts[workout_name]["exercises"]
            self.edit_workout_table(workout_name, exercises)
        else:
            messagebox.showerror("Erro", "Treino não encontrado.")

    def edit_workout_table(self, workout_name, exercises):
        edit_workout_window = tk.Toplevel(self.master)
        edit_workout_window.title(f"{workout_name} - Editar Treino")

        tree = ttk.Treeview(edit_workout_window, columns=("name", "series", "repetitions", "load"), show="headings")
        tree.heading("name", text="Exercício")
        tree.heading("series", text="Séries")
        tree.heading("repetitions", text="Repetições")
        tree.heading("load", text="Carga")

        for exercise in exercises:
            tree.insert("", "end", values=(exercise["name"], exercise["series"], exercise["repetitions"], exercise["load"]))

        tree.pack()
        edit_button = tk.Button(edit_workout_window, text="Editar Exercício", command=lambda: self.edit_exercise(workout_name, tree))
        edit_button.pack()

    def edit_exercise(self, workout_name, tree):
        selected_item = tree.selection()
        if selected_item:
            selected_index = tree.index(selected_item)
            exercise = self.workouts[workout_name]["exercises"][selected_index]

            new_series = tk.simpledialog.askinteger("Editar Exercício", "Número de séries:", initialvalue=exercise["series"])
            new_repetitions = tk.simpledialog.askinteger("Editar Exercício", "Número de repetições:", initialvalue=exercise["repetitions"])
            new_load = tk.simpledialog.askfloat("Editar Exercício", "Carga utilizada:", initialvalue=exercise["load"])

            exercise["series"] = new_series
            exercise["repetitions"] = new_repetitions
            exercise["load"] = new_load

            tree.item(selected_item, values=(exercise["name"], exercise["series"], exercise["repetitions"], exercise["load"]))

            messagebox.showinfo("Exercício Editado", "Exercício editado com sucesso.")
        else:
            messagebox.showerror("Erro", "Selecione um exercício para editar.")

    def save_data(self):
        # Salvar dados em um arquivo JSON
        data = {"logged_in": self.logged_in, "current_user": self.current_user, "workouts": self.workouts,
                "users": self.users}
        with open("myfitapp_data.json", "w") as file:
            json.dump(data, file)

    def load_data(self):
        try:
            # Carregar dados de um arquivo JSON
            with open("myfitapp_data.json", "r") as file:
                file_content = file.read()
                if file_content:
                    data = json.loads(file_content)
                    self.logged_in = data.get("logged_in", False)
                    self.current_user = data.get("current_user", None)
                    self.workouts = data.get("workouts", {})
                    self.users = data.get("users", {})
                else:
                    # Se o arquivo estiver vazio, inicializa os atributos
                    self.logged_in = False
                    self.current_user = None
                    self.workouts = {}
                    self.users = {}
        except FileNotFoundError:
            # Arquivo não encontrado (ainda não há dados salvos)
            pass


if __name__ == "__main__":
    root = tk.Tk()
    app = MyFitApp(root)
    root.mainloop()
