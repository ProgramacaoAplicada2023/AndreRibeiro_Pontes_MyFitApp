from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///myfitapp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'sua_chave_secreta_myfitapp'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Workout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100), nullable=True)
    exercises = db.relationship('Exercise', backref='workout', lazy=True)

class Exercise(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workout_id = db.Column(db.Integer, db.ForeignKey('workout.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    sets = db.Column(db.Integer, nullable=False)
    reps = db.Column(db.Integer, nullable=False)
    weight = db.Column(db.Float, nullable=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        hashed_password = generate_password_hash(password, method='sha256')
        new_user = User(email=email, password=hashed_password)

        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')
        except:
            return 'Erro ao criar a conta'

    return render_template('register.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            flash('Login bem-sucedido!', 'success')  # Adicionando uma mensagem de sucesso
            return redirect(url_for('home'))  # Redireciona para a rota 'home'
        else:
            flash('Login inválido. Verifique suas credenciais e tente novamente.', 'danger')  # Adicionando uma mensagem de erro

    return render_template('login.html')
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    user = User.query.get(user_id)

    workouts = Workout.query.filter_by(user_id=user_id).all()

    if request.method == 'POST':
        workout_id = request.form['workout_id']
        action = request.form['action']

        if action == 'add_series':
            session['current_workout_id'] = int(workout_id)
            return redirect('/add_series')

        elif action == 'view_workouts':
            return redirect(url_for('view_workouts'))

        elif action == 'delete_series':
            return redirect(url_for('delete_series', workout_id=workout_id))

    return render_template('dashboard.html', user=user, workouts=workouts)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect('/')


@app.route('/add_workout_name', methods=['GET', 'POST'])
def add_workout_name():
    if request.method == 'POST':
        session['current_workout_name'] = request.form['workout_name']
        return redirect('/select_exercises')

    return render_template('add_workout_name.html')

@app.route('/add_workout', methods=['POST'])
def add_workout():
    if 'current_workout_name' not in session:
        return redirect('/add_workout_name')

    if request.method == 'POST':
        current_workout_name = session['current_workout_name']
        logging.debug(f"Nome do treino: {current_workout_name}")

        # Lógica para lidar com a seleção de exercícios, se necessário

        new_workout = Workout(user_id=session['user_id'], name=current_workout_name)

        try:
            db.session.add(new_workout)
            db.session.commit()

            logging.info("Treino adicionado com sucesso!")

            if 'add_another' in request.form:
                flash('Treino criado com sucesso! Adicione outro exercício.', 'success')
                return redirect('/select_exercises')
            else:
                flash('Treino criado com sucesso!', 'success')
                return redirect('/dashboard')

        except Exception as e:
            db.session.rollback()
            logging.error(f"Erro ao adicionar treino: {str(e)}")
            flash('Erro ao adicionar treino', 'danger')
            return redirect('/dashboard')

    return render_template('add_workout.html', workout_name=session['current_workout_name'])

@app.route('/add_workout', methods=['GET'])
def display_add_workout_form():
    return render_template('add_workout_name.html')

# ... (código existente)

@app.route('/select_exercises', methods=['GET', 'POST'])
def select_exercises():
    if 'current_workout_name' not in session:
        return redirect('/add_workout_name')

    if request.method == 'POST':
        exercise_name = request.form['exercise_name']
        sets = request.form['sets']
        reps = request.form['reps']
        weight = request.form['weight']

        exercise_info = {
            'name': exercise_name,
            'sets': sets,
            'reps': reps,
            'weight': weight
        }

        if 'workout_info' not in session:
            session['workout_info'] = []

        session['workout_info'].append(exercise_info)

        if 'add_another' in request.form:
            flash('Exercício adicionado com sucesso! Adicione outro exercício.', 'success')
            return redirect('/select_exercises')
        else:
            flash('Treino criado com sucesso!', 'success')
            return redirect('/home')  # Alteração aqui para redirecionar para a página home

    return render_template('select_exercises.html', workout_name=session['current_workout_name'])



@app.route('/add_exercise', methods=['POST'])
def add_exercise():
    if 'current_workout_id' not in session:
        return redirect('/home')  # Redirecionar para a página inicial se o ID do treino não estiver definido

    if request.method == 'POST':
        exercise_name = request.form['exercise_name']
        sets = request.form['sets']
        reps = request.form['reps']
        weight = request.form['weight']

        new_exercise = Exercise(workout_id=session['current_workout_id'], name=exercise_name, sets=sets, reps=reps, weight=weight)

        try:
            db.session.add(new_exercise)
            db.session.commit()

            if 'add_another' in request.form:
                flash('Exercício adicionado com sucesso! Adicione outro exercício.', 'success')
                return redirect('/select_exercises')
            elif 'add_workout' in request.form:
                flash('Treino criado com sucesso!', 'success')
                return redirect('/dashboard')
        except:
            return 'Erro ao adicionar exercício'

    return redirect('/select_exercises')  # Redirecionar para a página de seleção de exercícios se algo der errado@app.route('/add_series', methods=['GET', 'POST'])
def add_series():
    if 'user_id' not in session or 'current_workout_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    user = User.query.get(user_id)

    workout_id = session['current_workout_id']
    workout = Workout.query.get(workout_id)

    if request.method == 'POST':
        exercise_id = request.form['exercise_id']
        sets = request.form['sets']
        reps = request.form['reps']
        weight = request.form['weight']

        exercise = Exercise.query.get(exercise_id)

        if not exercise or exercise.workout_id != workout_id:
            flash('Erro ao adicionar séries. Exercício inválido.', 'danger')
            return redirect('/dashboard')

        # Atualiza as séries no exercício existente
        exercise.sets = sets
        exercise.reps = reps
        exercise.weight = weight

        try:
            db.session.commit()
            flash('Séries adicionadas com sucesso!', 'success')
            return redirect('/dashboard')
        except:
            flash('Erro ao adicionar séries', 'danger')
            return redirect('/dashboard')

    return render_template('add_series.html', workout=workout)

    return render_template('add_series.html', workout=workout)

@app.route('/delete_series/<int:workout_id>', methods=['GET', 'POST'])
def delete_series(workout_id):
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    user = User.query.get(user_id)

    workout = Workout.query.get(workout_id)
    exercises = Exercise.query.filter_by(workout_id=workout_id).all()

    if request.method == 'POST':
        exercise_ids_to_delete = request.form.getlist('exercise_ids_to_delete')

        for exercise_id in exercise_ids_to_delete:
            exercise = Exercise.query.get(int(exercise_id))
            db.session.delete(exercise)

        try:
            db.session.commit()
            flash('Séries excluídas com sucesso!', 'success')
            return redirect('/dashboard')
        except:
            flash('Erro ao excluir séries', 'danger')
            return redirect('/dashboard')

    return render_template('delete_series.html', workout=workout, exercises=exercises)

@app.route('/workout_details/<int:workout_id>', methods=['GET'])
def workout_details(workout_id):
    user_id = session['user_id']
    workout = Workout.query.filter_by(user_id=user_id, id=workout_id).first()

    if not workout:
        return 'Treino não encontrado'

    exercises = Exercise.query.filter_by(workout_id=workout.id).all()

    return render_template('workout_details.html', workout=workout, exercises=exercises)


@app.route('/view_workouts', methods=['GET', 'POST'])
def view_workouts():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    workouts = Workout.query.filter_by(user_id=user_id).all()

    print(workouts)  # Adicione esta linha para imprimir os treinos no console

    return render_template('view_workouts.html', workouts=workouts)

@app.route('/edit_workout/<int:workout_id>', methods=['GET', 'POST'])
def edit_workout(workout_id):
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    user = User.query.get(user_id)

    workout = Workout.query.get(workout_id)

    if not workout or workout.user_id != user_id:
        return redirect('/view_workouts')

    if request.method == 'POST':
        new_name = request.form['new_name']
        workout.name = new_name
        db.session.commit()
        return redirect('/view_workouts')

    return render_template('edit_workout.html', workout=workout)

    workout = saved_workouts[workout_index]

    if request.method == 'POST':
        new_name = request.form['new_name']
        saved_workouts[workout_index]['name'] = new_name
        return redirect('/view_workouts')

    return render_template('edit_workout.html', workout=workout)

@app.route('/view_workout_by_name', methods=['GET', 'POST'])
def view_workout_by_name():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    workouts = Workout.query.filter_by(user_id=user_id).all()

    if request.method == 'POST':
        workout_name = request.form['workout_name']
        selected_workout = Workout.query.filter_by(user_id=user_id, name=workout_name).first()

        if selected_workout:
            exercises = Exercise.query.filter_by(workout_id=selected_workout.id).all()
            return render_template('view_workout_by_name.html', workout=selected_workout, exercises=exercises)
        else:
            flash('Treino não encontrado', 'danger')

    return render_template('view_workout_by_name.html', workouts=workouts)



if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)